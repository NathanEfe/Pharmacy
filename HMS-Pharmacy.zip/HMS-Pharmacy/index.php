﻿<?php 
      include('assets/inc/header.php');
      // $data->pageContent($_SESSION['role']);
?>



<?php
// count number of drugs
include('db_connect.php');


$sql_drug_count = 'SELECT COUNT(*) AS total_drugs FROM drugs';
$result = $conn->query($sql_drug_count);

$total_drugs = 0;
if ($result && $row = $result->fetch_assoc()) {
    $total_drugs = $row['total_drugs'];
}

?>


<?php
//show low stock alerts
include 'db_connect.php';

$lowStockThreshold = 20;
$query = "SELECT COUNT(*) AS total_low_stock FROM drugs WHERE quantity < $lowStockThreshold";
$result = $conn->query($query);
$row = $result->fetch_assoc();
$total_low_stock = $row['total_low_stock'];
?>


<?php
//show expired drugs
include 'db_connect.php';

$today = date('Y-m-d');
$query = "SELECT COUNT(*) AS total_expired FROM drugs WHERE expiry_date < '$today'";
$result = $conn->query($query);
$row = $result->fetch_assoc();
$total_expired = $row['total_expired'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Dashboard</title>
      <link rel="stylesheet" href="./assets/css/index.css">
</head>
<body>
  <!-- <p>Welcome, Your User ID is: <?php echo $_SESSION["user_id"]; ?></p> -->

      <h3>Dashboard</h3>
  <div class="dashboard">
    <div class="card green">
      <h2>Drugs In Stock</h2>
      <div class="number">
        <?php
        echo $total_drugs;
        ?>
      </div>
      <div class="desc">Total items</div>
    </div>


    <div class="card orange">
      <h2>Low Stock Alerts</h2>
      <div class="number">
        <?php echo $total_low_stock; ?>
      </div>
      <div class="desc">Drugs below <?php echo $lowStockThreshold; ?> units</div>
    </div>


  <div class="card red">
    <h2>Expired Drugs</h2>
    <div class="number">
      <?php echo $total_expired; ?>
    </div>
    <div class="desc">Drugs past expiry</div>
  </div>

</div>

    <h3>Quick Links</h3>

  <div class="dashboard container">
    <a href="inventory.php">
      <div class="card blue">
        <h2>Visit Inventory</h2>
        <div class="desc">View your Inventory</div>
      </div>
    </a>

    <a href="reports.php">
      <div class="card blue">
        <h2>View Daily Reports</h2>
        <div class="desc">View All Reports Here</div>
      </div>
    </a>
    <a href="prescription.php">
      <div class="card blue">
        <h2>View Prescriptions</h2>
        <div class="desc">View Doctor's Prescriptions</div>
      </div>
    </a>
    <a href="medical_form.php">
      <div class="card blue">
        <h2>View Medical Form</h2>
        <div class="desc">View your forms</div>
      </div>
    </a>
</div>


<div class="container">
  <div class="card mb-4 shadow-sm">
    <div class="card-header bg-danger text-white">
      <strong> Alerts</strong>
    </div>
  <div class="container pb-4 pt-4" style="padding-bottom: 10px; padding-top: 20px;">
 <?php
include 'db_connect.php';
// Total Drugs in Stock
$res_total = $conn->query("SELECT COUNT(*) AS total FROM drugs");
$total = $res_total->fetch_assoc()['total'];

// Low Stock
$res_low = $conn->query("SELECT COUNT(*) AS low FROM drugs WHERE quantity < 20");
$low_stock = $res_low->fetch_assoc()['low'];

// Expired Drugs
$today = date('Y-m-d');
$res_expired = $conn->query("SELECT COUNT(*) AS expired FROM drugs WHERE expiry_date < '$today'");
$expired = $res_expired->fetch_assoc()['expired'];
?>

<!--  Alerts -->
  <div class="alert alert-success d-flex justify-content-between align-items-center" role="alert">
    <div><strong>Total Drugs:</strong> <?php         echo $total_drugs; ?> in stock.</div>
    <i class="bi bi-capsule"></i>
  </div>

  <div class="alert alert-warning d-flex justify-content-between align-items-center" role="alert">
    <div><strong>Low Stock Alert:</strong> <?php echo $total_low_stock; ?> drug(s) need restocking.</div>
    <i class="bi bi-exclamation-triangle"></i>
  </div>

  <div class="alert alert-danger d-flex justify-content-between align-items-center" role="alert">
    <div><strong>Expired Drugs:</strong> <?php echo $total_expired; ?> drug(s) have expired.</div>
    <i class="bi bi-calendar-x"></i>
  </div>

      </div>
    </div>
  </div>
</body>
</html>

<?php

      include('assets/inc/footer.php'); 
?>