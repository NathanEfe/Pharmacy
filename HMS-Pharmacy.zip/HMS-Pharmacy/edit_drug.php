<?php 
include('assets/inc/header.php');
?>
<h3>Edit Drug</h3>

<?php

include('db_connect.php');
// Get drug ID
if (!isset($_GET['id'])) {
    die("Invalid request.");
}
$id = intval($_GET['id']);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $drug_name = $_POST['drug_name'];
    $quantity = intval($_POST['quantity']);
    $unit = $_POST['unit'];
    $expiry_date = $_POST['expiry_date'];
    $category = $_POST['category'];

    // Automatically determine status
    $today = date('Y-m-d');
    if ($expiry_date < $today) {
        $status = "EXPIRED";
    } elseif ($quantity === 0) {
        $status = "OUT OF STOCK";
    } elseif ($quantity < 20) {
        $status = "LOW STOCK";
    } else {
        $status = "OK";
    }

    $update_sql = "UPDATE drugs SET 
                    drug_name='$drug_name',
                    quantity=$quantity,
                    unit='$unit',
                    expiry_date='$expiry_date',
                    category='$category',
                    status='$status'
                   WHERE id=$id";

    if ($conn->query($update_sql) === TRUE) {
        echo "<script>alert('Drug updated successfully'); window.location.href='inventory.php';</script>";
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}

// Fetch drug details
$sql = "SELECT * FROM drugs WHERE id=$id";
$result = $conn->query($sql);

if ($result->num_rows !== 1) {
    die("Drug not found.");
}
$drug = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Drug</title>
</head>
<body class="bg-light">

<div class="container mt-5">
    <form method="POST" class="bg-white p-4 rounded shadow-sm">
        <div class="mb-3">
            <label class="form-label">Drug Name</label>
            <input type="text" name="drug_name" value="<?= htmlspecialchars($drug['drug_name']) ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Quantity</label>
            <input type="number" name="quantity" value="<?= $drug['quantity'] ?>" class="form-control" required>
        </div>
        <div class="col-md-4">
            <label for="unit" class="form-label">Unit</label>
            <select class="form-select" id="unit" name="unit" required>
                <option <?= ($drug['unit'] == 'tabs') ? 'selected' : '' ?> value="tabs">Tabs</option>
                <option <?= ($drug['unit'] == 'caps') ? 'selected' : '' ?> value="caps">Caps</option>
                <option <?= ($drug['unit'] == 'ml') ? 'selected' : '' ?> value="ml">mL</option>
                <option <?= ($drug['unit'] == 'vials') ? 'selected' : '' ?> value="vials">Vials</option>
                <option <?= ($drug['unit'] == 'ampoules') ? 'selected' : '' ?> value="ampoules">Ampoules</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Expiry Date</label>
            <input type="date" name="expiry_date" value="<?= $drug['expiry_date'] ?>" class="form-control" required>
        </div>
        <div class="col-md-4">
            <label for="category" class="form-label">Category</label>
            <select class="form-select" id="category" name="category" required>
                <option <?= ($drug['category'] == 'Antibiotic') ? 'selected' : '' ?>>Antibiotic</option>
                <option <?= ($drug['category'] == 'Analgesic') ? 'selected' : '' ?>>Analgesic</option>
                <option <?= ($drug['category'] == 'Antimalarial') ? 'selected' : '' ?>>Antimalarial</option>
                <option <?= ($drug['category'] == 'Antifungal') ? 'selected' : '' ?>>Antifungal</option>
                <option <?= ($drug['category'] == 'Antiviral') ? 'selected' : '' ?>>Antiviral</option>
            </select>
        </div>
        
        <button type="submit" class="btn btn-primary mt-4">Update Drug</button>
        <a href="inventory.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>

<?php 
include('assets/inc/footer.php');
?>
