
<?php
      include('assets/inc/header.php'); 
?>


<?php
      include('db_connect.php'); 


// Fetch all drugs
$sql = "SELECT * FROM drugs ORDER BY expiry_date ASC";
$result = $conn->query($sql);

// Counter
$totalDrugs = 0;
$lowStock = 0;
$OutofStock = 0;
$expired = 0;
$todayDispensed = 72;

$today = date("Y-m-d");
// Automatically update expired status
$update_expired_sql = "UPDATE drugs SET status = 'EXPIRED' WHERE DATE(expiry_date) < ? AND status != 'EXPIRED'";
$update_stmt = $conn->prepare($update_expired_sql);
$update_stmt->bind_param("s", $today);
$update_stmt->execute();
$update_stmt->close();



// Check for expired/low stock
while ($row = $result->fetch_assoc()) {
    $totalDrugs++;
    if ($row['quantity'] < 20) $lowStock++;
    if ($row['quantity'] == 0) $OutofStock++;
    if (date('Y-m-d', strtotime($row['expiry_date'])) < $today) $expired++;
}

$result->data_seek(0);
?>


<?php
//search bar
include 'db_connect.php';

$search = '';
if (isset($_GET['search']) && !empty(trim($_GET['search']))) {
    $search = $conn->real_escape_string($_GET['search']);
    $query = "SELECT * FROM drugs WHERE drug_name LIKE '%$search%' ORDER BY drug_name ASC";
} else {
    $query = "SELECT * FROM drugs ORDER BY drug_name ASC";
}

$result = $conn->query($query);

if ($result->num_rows == 0) {
    echo "<p class='text-danger'>No drugs found for '<strong>" . htmlspecialchars($search) . "</strong>'</p>";
}
?>
<link rel="stylesheet" href="./assets/css/index.css">

<h3 class="mb-4">Drug Inventory</h3>

<form method="GET" action="inventory.php">
  <div class="input-group mb-3">
    <span class="input-group-text">Search Drug Here...</span>
    <input type="text" name="search" class="form-control" placeholder="Search by Drug Name..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
    <button class="btn btn-primary" type="submit">Search</button>
  </div>
</form>


  <div class="card mb-4 shadow-sm mt-4">
  <div class="card-header bg-dark text-white">
    <strong>Drug Inventory</strong>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered table-hover align-middle text-center">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Drug Name</th>
            <th>Quantity</th>
            <th>Unit</th>
            <th>Expiry Date</th>
            <th>Category</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
      <tbody>
    <?php
    if ($result->num_rows > 0) {
        $i = 1;
        while ($row = $result->fetch_assoc()) {
            // Choose badge color based on status
            $statusColor = "secondary";
            if ($row['status'] === "OK") $statusColor = "success";
            else if ($row['status'] === "LOW STOCK") $statusColor = "warning";
            else if ($row['status'] === "EXPIRED") $statusColor = "danger";
            else if ($row['status'] === "OUT OF STOCK") $statusColor = "danger";

           echo "<tr>
        <td>{$i}</td>
        <td>{$row['drug_name']}</td>
        <td>{$row['quantity']}</td>
        <td>{$row['unit']}</td>
        <td>{$row['expiry_date']}</td>
        <td>{$row['category']}</td>
        <td><span class='badge bg-{$statusColor}'>{$row['status']}</span></td>
        <td>
          <a href='edit_drug.php?id={$row['id']}' class='btn btn-sm btn-outline-primary'>Edit</a>
          <a href='delete_drug.php?id={$row['id']}' class='btn btn-sm btn-outline-danger' onclick=\"return confirm('Are you sure you want to delete this drug?');\">Delete</a>
        </td>
      </tr>";
$i++;

        }
    } else {
        echo "<tr><td colspan='8'>No drugs found.</td></tr>";
    }
    ?>
  </tbody>
      </table>
        <a href="add_drug.php">
      <button class="btn btn-primary">Add New Drug</button>
      </a>
    </div>
  </div>
</div>



<?php

      include('assets/inc/footer.php'); 
?>
   