<?php 
include('assets/inc/header.php');
include('db_connect.php');

if (!isset($_GET['prescription_id']) || !isset($_GET['patient_id'])) {
    die("<div class='alert alert-danger'>Invalid prescription or patient ID.</div>");
}

$prescription_id = intval($_GET['prescription_id']);
$patient_id = $conn->real_escape_string($_GET['patient_id']);

if ($prescription_id === 0 || empty($patient_id)) {
    echo "<div class='alert alert-danger'>Invalid prescription or patient ID.</div>";
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quantities = $_POST['quantity_dispensed'] ?? [];
    $all_success = true;

    foreach ($quantities as $drug_id => $quantity_to_dispense) {
        $drug_id = intval($drug_id);
        $quantity_to_dispense = intval($quantity_to_dispense);

        // Get the current drug
$stmt = $conn->prepare("
    SELECT pi.quantity_dispensed, pi.status, pi.quantity_prescribed, d.quantity AS stock_quantity, d.expiry_date
    FROM prescription_items pi
    JOIN drugs d ON pi.drug_id = d.id
    WHERE pi.prescription_id = ? AND pi.drug_id = ?
");
$stmt->bind_param("ii", $prescription_id, $drug_id);
$stmt->execute();
$item_result = $stmt->get_result();

if ($item_result->num_rows === 0) {
    echo "<div class='alert alert-danger'>Invalid drug or prescription.</div>";
    $all_success = false;
    continue;
}

$item = $item_result->fetch_assoc();
$already_dispensed = (int) $item['quantity_dispensed'];
$stock_quantity = (int) $item['stock_quantity'];
$expiry_date = $item['expiry_date'];
$today = date('Y-m-d');

// Expired drug
if ($expiry_date && $expiry_date < $today) {
    echo "<div class='alert alert-danger'>Drug ID $drug_id is expired (Expired on $expiry_date).</div>";
    $all_success = false;
    continue;
}
       if ($item['status'] === 'Dispensed') {
    echo "<div class='alert alert-info'>Drug ID $drug_id has already been dispensed.</div>";
    continue;
}
    if ($quantity_to_dispense <= 0 || $quantity_to_dispense > $stock_quantity) {
    echo "<div class='alert alert-danger'>Invalid quantity for Drug ID $drug_id. Not enough stock.</div>";
    $all_success = false;
    continue;
}


        // Update prescription item
        $update_stmt = $conn->prepare("UPDATE prescription_items SET quantity_dispensed = ?, status = 'Dispensed' WHERE prescription_id = ? AND drug_id = ?");
        $update_stmt->bind_param("iii", $quantity_to_dispense, $prescription_id, $drug_id);

if (!$update_stmt->execute()) {

            echo "<div class='alert alert-danger'>Failed to update prescription item.</div>";
            $all_success = false;
            continue;
        }

        // Update stock

        // Deduct from inventory
        $stock_stmt = $conn->prepare("UPDATE drugs SET quantity = quantity - ? WHERE id = ?");
        $stock_stmt->bind_param("ii", $quantity_to_dispense, $drug_id);
        if (!$stock_stmt->execute()) {
            echo "<div class='alert alert-danger'>Failed to update stock for drug ID $drug_id.</div>";
            $all_success = false;
        }

// Update drug status
$current_stock = $stock_quantity - $quantity_to_dispense;

if ($current_stock <= 0) {
    $new_status = 'OUT OF STOCK';
} elseif ($current_stock <= 20) {
    $new_status = 'LOW STOCK';
} else {
    $new_status = 'OK';
}

$status_stmt = $conn->prepare("UPDATE drugs SET quantity = ?, status = ? WHERE id = ?");
$status_stmt->bind_param("isi", $current_stock, $new_status, $drug_id);
$status_stmt->execute();

// $drug_info = $drug_stmt->get_result()->fetch_assoc();
// $drug_stmt->close();

        // $current_stock = $drug_info['quantity'];

        if ($expiry_date < $today) {
            $new_status = 'EXPIRED';
        } elseif ($current_stock <= 0) {
            $new_status = 'OUT OF STOCK';
        } elseif ($current_stock <= 20) {
            $new_status = 'LOW STOCK';
        } else {
            $new_status = 'OK';
        }



// Update status in drugs table
        $status_stmt = $conn->prepare("UPDATE drugs SET status = ? WHERE id = ?");
        $status_stmt->bind_param("si", $new_status, $drug_id);
        $status_stmt->execute();
        $status_stmt->close();
        $update_stmt->close();
        $stock_stmt->close();
    }

    // Update prescription status if all drugs are dispensed
$check_sql = "
    SELECT 
        SUM(CASE WHEN status = 'Dispensed' THEN 1 ELSE 0 END) AS dispensed_count,
        COUNT(*) AS total_count
    FROM prescription_items
    WHERE prescription_id = ?
";

$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("i", $prescription_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result()->fetch_assoc();

$dispensed = (int)$check_result['dispensed_count'];
$total = (int)$check_result['total_count'];

//Debug
echo "<pre>Dispensed: $dispensed | Total: $total</pre>";

//Update prescription status
if ($dispensed === $total && $total > 0) {
    $conn->query("UPDATE prescriptions SET status = 'Dispensed' WHERE id = $prescription_id");
} elseif ($dispensed > 0) {
    $conn->query("UPDATE prescriptions SET status = 'Partially Dispensed' WHERE id = $prescription_id");
} else {
    $conn->query("UPDATE prescriptions SET status = 'Pending' WHERE id = $prescription_id");
}

$check_stmt->close();


$status_result = $conn->query("SELECT status FROM prescriptions WHERE id = $prescription_id")->fetch_assoc();
echo "<div class='alert alert-info'>Updated Status: {$status_result['status']}</div>";


}

// REFRESH prescription items after update
$sql = "
    SELECT 
        prescriptions.id AS prescription_id,
        prescriptions.prescribed_at,
        patients.patient_id,
        patients.full_name AS patient_name,
        prescription_items.quantity_prescribed,
        prescription_items.quantity_dispensed,
        prescription_items.status,
        drugs.id AS drug_id,
        drugs.drug_name,
        drugs.quantity AS stock_quantity
    FROM prescriptions
    JOIN patients ON prescriptions.patient_id = patients.id
    JOIN prescription_items ON prescriptions.id = prescription_items.prescription_id
    JOIN drugs ON prescription_items.drug_id = drugs.id
    WHERE prescriptions.id = $prescription_id
      AND patients.patient_id = '$patient_id'
";

$result = $conn->query($sql);
if ($result->num_rows === 0) {
    echo "<div class='alert alert-warning'>No matching prescription found.</div>";
    exit;
}

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // echo "<pre>";
        // print_r($row);
        // echo "</pre>";
    }
} else {
    echo "No results found.";
}

$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$prescription_items = [];
while ($row = $result->fetch_assoc()) {
    $prescription_items[] = $row;
}
?>

<div class="container mt-5">
    <h3>Dispense Drugs</h3>
    <div class="card">
        <div class="card-body">
            <p><strong>Prescription ID:</strong> <?= $prescription_items[0]['prescription_id'] ?></p>
            <p><strong>Patient ID:</strong> <?= htmlspecialchars($prescription_items[0]['patient_id']) ?></p>
            <p><strong>Patient Name:</strong> <?= htmlspecialchars($prescription_items[0]['patient_name']) ?></p>
            <p><strong>Prescribed At:</strong> <?= $prescription_items[0]['prescribed_at'] ?></p>

                <form method="POST" action="dispense_drug.php?prescription_id=<?= $prescription_id ?>&patient_id=<?= $patient_id ?>">
                <input type="hidden" name="prescription_id" value="<?= $prescription_id ?>">
                <input type="hidden" name="drug_id[]" value="8">


                <?php foreach ($prescription_items as $item): ?>
                    <div class="border p-3 mb-3">
                        <p><strong>Drug:</strong> <?= htmlspecialchars($item['drug_name']) ?></p>
                        <p><strong>Prescribed Quantity:</strong> <?= intval($item['quantity_prescribed']) ?></p>
                        <p><strong>Stock Available:</strong> <?= intval($item['stock_quantity']) ?></p>
                        <p><strong>Status:</strong> <?= htmlspecialchars($item['status']) ?></p>

                    <?php 
                    $today = date('Y-m-d');
                    $is_expired = isset($item['expiry_date']) && $item['expiry_date'] < $today;
                    ?>

            <?php if ($item['status'] !== 'Dispensed' && !$is_expired): ?>
                <label>Quantity to Dispense:</label>
                <input type="number" name="quantity_dispensed[<?= $item['drug_id'] ?>]" class="form-control" min="1" max="<?= $item['stock_quantity'] ?>" required>
              
            <?php elseif ($is_expired): ?>
                <div class="alert alert-danger">This drug has expired and cannot be dispensed.</div>
            <?php else: ?>
                <div class="alert alert-info">Already dispensed (<?= intval($item['quantity_dispensed']) ?>).</div>
            <?php endif; ?>


                    </div>
                <?php endforeach; ?>
<button type="submit" class="btn btn-success">Dispense</button>
            </form>
        </div>
    </div>
</div>

<?php include('assets/inc/footer.php'); ?>
