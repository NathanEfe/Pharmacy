<?php
// Connect to DB
include 'db_connect.php';

$filter_date = $_GET['date'] ?? '';

$where = "WHERE prescription_items.status = 'Dispensed'";

if (!empty($filter_date)) {
  $escaped_date = $conn->real_escape_string($filter_date);
  $where .= " AND DATE(prescription_items.dispensed_at) = '$escaped_date'";
}

// Same query from reports.php
$sql = "
  SELECT 
    prescriptions.id AS prescription_id,
    patients.patient_id,
    patients.full_name,
    prescription_items.quantity_dispensed,
    GROUP_CONCAT(drugs.drug_name SEPARATOR ', ') AS drug_names,
    MAX(prescription_items.status) AS status,
    MAX(prescription_items.dispensed_at) AS dispensed_at
  FROM prescriptions
  JOIN patients ON prescriptions.patient_id = patients.id
  JOIN prescription_items ON prescriptions.id = prescription_items.prescription_id
  JOIN drugs ON prescription_items.drug_id = drugs.id
  $where
  GROUP BY prescriptions.id, patients.patient_id, patients.full_name
  ORDER BY dispensed_at DESC
";

$result = $conn->query($sql);

// Set CSV headers
header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename="dispensed_drugs_report.csv"');

$output = fopen('php://output', 'w');

// Output header row
fputcsv($output, [
  'Prescription ID',
  'Patient ID',
  'Patient Name',
  'Drug Name(s)',
  'Quantity Dispensed',
  'Status',
  'Dispensed At'
]);

// Output rows
if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
      $row['prescription_id'],
      $row['patient_id'],
      $row['full_name'],
      $row['drug_names'],
      $row['quantity_dispensed'],
      $row['status'],
      $row['dispensed_at']
    ]);
  }
} else {
  // Optional: add a row showing no results
  fputcsv($output, ['No records found']);
}

fclose($output);
$conn->close();
exit;
?>
