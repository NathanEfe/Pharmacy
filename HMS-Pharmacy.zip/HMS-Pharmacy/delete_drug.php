<?php

$conn = new mysqli("localhost", "root", "", "pharmacy");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("DELETE FROM drugs WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $stmt->close();
}

$conn->close();
header("Location: inventory.php");
exit;
?>


<?php

      include('assets/inc/header.php'); 
?>
   

<?php

      include('assets/inc/footer.php'); 
?>
   