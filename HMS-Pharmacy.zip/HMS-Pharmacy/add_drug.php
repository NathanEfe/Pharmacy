<?php
$conn = new mysqli("localhost", "root", "", "pharmacy");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['drug_name'];
    $quantity = $_POST['quantity'];
    $unit = $_POST['unit'];
    $expiry = $_POST['expiry_date'];
    $category = $_POST['category'];

    $status = 'OK';
    if ($quantity < 20) $status = 'LOW STOCK';
    if ($expiry < date("Y-m-d")) $status = 'EXPIRED';

    $stmt = $conn->prepare("INSERT INTO drugs (drug_name, quantity, unit, expiry_date, category, status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sissss", $name, $quantity, $unit, $expiry, $category, $status);
    $stmt->execute();

    header("Location: inventory.php");
}
?>
<?php 
      include('assets/inc/header.php');
?>





      <div class="text-start mb-4">
        <a href="inventory.php">
        <button type="submit" class="btn btn-success">Go Back</button>
        </a>
      </div>

<div class="card mb-4 shadow-sm">
  <div class="card-header bg-success text-white">
    <strong>Add New Drug</strong>
  </div>
  <div class="card-body">
    <form action="add_drug.php" method="post">
      <div class="row mb-3">
        <div class="col-md-6">
          <label for="drugName" class="form-label">Drug Name</label>
          <input type="text" class="form-control" id="drugName" placeholder="e.g. Amoxicillin 500mg" name="drug_name">
        </div>
      
      </div>

      <div class="row mb-3">
       
        <div class="col-md-4">
          <label for="quantity" class="form-label">Quantity</label>
      <input type="number" class="form-control" id="quantity" placeholder="e.g. 120" name="quantity">
        </div>
        <div class="col-md-4">
          <label for="unit" class="form-label">Unit</label>
          <select class="form-select" id="unit" name="unit">
            <option selected disabled>Choose...</option>
            <option value="tabs">Tabs</option>
            <option value="caps">Caps</option>
            <option value="ml">mL</option>
            <option value="vials">Vials</option>
            <option value="ampoules">Ampoules</option>
          </select>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col-md-4">
          <label for="expiryDate" class="form-label">Expiry Date</label>
          <input type="date" class="form-control" id="expiryDate" name="expiry_date">
        </div>
        <div class="col-md-4">
          <label for="category" class="form-label">Category</label>
          <select class="form-select" id="category"  name="category">
            <option selected disabled>Choose...</option>
            <option>Antibiotic</option>
            <option>Analgesic</option>
            <option>Antimalarial</option>
            <option>Antifungal</option>
            <option>Antiviral</option>
          </select>
        </div>
      </div>

      <!-- <div class="row mb-4">
        <div class="col-md-6">
          <label for="status" class="form-label">Status</label>
          <select class="form-select" id="status">
            <option selected disabled>Choose...</option>
            <option value="ok">OK</option>
            <option value="low">Low Stock</option>
            <option value="expired">Expired</option>
          </select>
        </div>
      </div> -->

      <div class="text-end">
        <button type="submit" class="btn btn-success">Add Drug</button>
      </div>
    </form>
  </div>
</div>



<?php 
      include('assets/inc/footer.php');
?>